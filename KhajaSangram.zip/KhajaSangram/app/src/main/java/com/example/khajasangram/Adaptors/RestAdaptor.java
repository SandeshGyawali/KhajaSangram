package com.example.khajasangram.Adaptors;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khajasangram.R;

import java.util.ArrayList;

public class RestAdaptor extends RecyclerView.Adapter<RestAdaptor.SearchViewHolder> {

    RecyclerView recyclerView;
    Context context;

    ArrayList<String> name = new ArrayList<>();
    ArrayList<String> address = new ArrayList<>();
    ArrayList<String> contact = new ArrayList<>();
    ArrayList<String> id = new ArrayList<>();
    ArrayList<String> created_date = new ArrayList<>();

    public RestAdaptor(RecyclerView recyclerView,Context context,ArrayList<String> name, ArrayList<String> address, ArrayList<String> contact, ArrayList<String> id, ArrayList<String> created_date) {
        this.recyclerView = recyclerView;
        this.context = context;

        this.name = name;
        this.address = address;
        this.id = id;
        this.contact = contact;
        this.created_date = created_date;
    }

    @NonNull
    @Override
    public RestAdaptor.SearchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.restaurant_display, parent, false);
        return new RestAdaptor.SearchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SearchViewHolder holder, int i) {
        holder.r_name.setText(name.get(i));
        holder.r_address.setText(address.get(i));
        holder.r_contact.setText(contact.get(i));
        holder.r_created_date.setText(created_date.get(i));
    }

    @Override
    public int getItemCount() {
        return name.size();
    }

    public class SearchViewHolder extends RecyclerView.ViewHolder {
        TextView r_name,
                r_address,
                r_contact,
                r_id,
                r_created_date;

        public SearchViewHolder(@NonNull View itemView) {
            super(itemView);

            r_name=itemView.findViewById(R.id.rest_name);
            r_address=itemView.findViewById(R.id.rest_address);
            r_contact = itemView.findViewById(R.id.rest_contact);
            r_created_date = itemView.findViewById(R.id.rest_createddate);
        }
    }
}
